# Acuan internal SobatNira

Target pertama adalah demo kompetisi sekitar **28 November 2026**. Tanggal resmi dan urutan presentasi menunggu kesepakatan tim.

- [Kebutuhan produk dan hak akses](product.md)
- [Proses produksi, identitas, stok, dan kalkulasi](production.md)
- [Arsitektur, data, dan kontrak integrasi](architecture.md)
- [Skenario demo, kriteria penerimaan, dan kesiapan pilot](demo-and-testing.md)
- [Pembagian kerja dan tugas awal](team.md)
- [Rancangan bisnis dan skalabilitas](business.md)
- [Keputusan, pertanyaan terbuka, dan sumber](decisions.md)
- [Setup lokal dan pengujian](../development.md)
