# Proses produksi dan aturan data

## Lima tahap

| Tahap | Bukti | Hubungan dan data |
| --- | --- | --- |
| Penerimaan tebu | Nota penerimaan | Kloter, pemasok, waktu, jenis tebu, berat bersih, Brix jika tersedia |
| Penggilingan | Nota penggilingan | Kloter asal, waktu dan volume nira |
| Pengolahan nira dan pemasakan | Satu nota gabungan | Batch, wajan, waktu selesai, kontribusi nira, BTP/gamping dan rework |
| Penimbangan hasil | Nota timbang | Batch dan berat hasil gula dalam kg |
| Grading | Nota grade | Satu grade per batch. Berat hasil dari nota timbang menjadi berat grade tersebut |

Urutkan menurut waktu kejadian produksi. Simpan waktu kirim, waktu konfirmasi dan waktu pengesahan tersendiri. Penimbangan dan grading memakai nota terpisah. Berat untuk grade berasal dari penimbangan yang sudah dilakukan sebelum grading.

## Identitas dan pencocokan

- Satu kiriman tebu adalah satu kloter. Kode tampil mengambil konteks nama/kode pemasok dan tanggal, dengan waktu atau pembeda ketika ada beberapa kiriman serupa. Figma menampilkan contoh `MJT-260926` dan `MJT-260926-1A`. Makna suffix dan format final masih perlu disepakati. Contoh `MJT-02928392818` disampaikan Ferdi saat Q&A.
- Backend membuat identitas internal unik. Kode tampilan, nama pemasok, tanggal, dan nomor wajan dapat membantu pencocokan. Untuk batch, pertimbangkan kloter konteks, nomor wajan, dan waktu masak. Satu wajan dapat dipakai berkali-kali dalam sehari.
- Sistem tidak mengandalkan ID yang tercetak pada nota. Usulan demo adalah menahan pengesahan relasi ambigu hingga admin memilih kandidat yang benar. Daftar kolom nyata dan perlakuan nota yang datang lebih dulu dari laporan induk masih perlu dipastikan.
- Pisahkan identitas pesan, dokumen, revisi, dan baris dokumen. Satu laporan pemasakan dapat berisi beberapa baris batch. ID kloter atau batch yang muncul pada beberapa tahap adalah relasi yang sah.

## Kontribusi material, rework, dan penutupan

- Tiga wajan. Isi normal 100–115 L nira per batch dengan kapasitas awal maksimum 115 L. Jika nira tersisa kurang dari 100 L, catat transfer lintas kloter, lalu kontribusi aktual pada batch penerima.
- Contoh sintetis. Kloter A menghasilkan 250 L. Dua batch menyerap masing-masing 115 L, lalu 20 L dipindah ke kloter B. Batch campuran dapat memakai 20 L dari A dan 80 L dari B. Simpan kedua sumber dan satu batch konteks.
- Rework umumnya 5–10 kg gula dan dicatat di nota masak. Simpan berat, batch sumber dan batch penerima. Ledger stok harus memastikan gula rework hanya dihitung sekali. Konversi dan dampak terhadap nilai serta kapasitas perlu konfirmasi.
- Titipan sisa nira merupakan aturan transfer yang dikonfirmasi. Usulan jatah produksi antarpemasok dan batas 5/5 dari proposal lama masih perlu validasi mitra.
- Penyelesaian kloter, kelengkapan validasi, dan finalisasi ekonomi punya kondisi sendiri. Kloter sumber dapat ditutup setelah transfer dicatat. Bagian ekonomi dari nira yang ditransfer menunggu batch penerima tervalidasi. Koreksi angka pada laporan sah tetap bisa dilakukan dengan audit. Penambahan batch atau perubahan relasi kloter yang ditutup memerlukan buka kembali.

## Hitungan dan satuan

Untuk batch campuran, proporsi kloter = liter yang disumbangkan kloter ÷ total liter nira batch. Alokasikan biaya dan laba menurut proporsi ini setelah batch tervalidasi dan bukukan ke setiap kloter asal. Contoh demo sintetis, biaya Rp200.000 dan laba Rp50.000 pada komposisi 20 L dan 80 L menghasilkan biaya/laba A Rp40.000/Rp10.000, dan B Rp160.000/Rp40.000. Dokumen Teknis mengilustrasikan alokasi berat hasil menurut liter. Kebijakan pembulatan dan basis biaya resmi tetap perlu disepakati.

| Ukuran | Dasar rancangan |
| --- | --- |
| Omzet | Jumlah berat hasil per grade × harga grade yang berlaku |
| Biaya tebu | Berat × harga beli atau nilai transaksi resmi, sesuai sumber yang disepakati |
| Laba dan margin | Omzet − biaya bahan − biaya operasional. Margin = laba ÷ omzet bila penyebut valid |
| Rendemen tebu | Berat gula ÷ berat tebu × 100% untuk lingkup material sepadan |
| Rasio nira/hasil | Berat gula (kg) ÷ nira (L), dan pemulihan nira L ÷ kg tebu. Cantumkan satuan |
| Stok | Saldo awal + masuk − keluar, dengan pergerakan transfer dan rework untuk rekonsiliasi |
| Waktu dan produktivitas | Selisih waktu kegiatan, waktu kirim terhadap kejadian, output per periode dan per run |
| Gamping/BTP | Simpan nilai dan satuan/takaran asal. Rumus Brix/volume dan konversi memerlukan SOP mitra |

Simpan uang dengan tipe desimal. Usulan internal adalah menyimpan presisi, membulatkan pada titik akuntansi yang ditentukan, dan merekonsiliasi sisa pembulatan secara deterministik. Simpan snapshot harga/konfigurasi yang berlaku. Kode tebu terkonfirmasi BL = Bululawang dan CN = Ceneng. Pertahankan kode asli seperti AP, BP, dan GGL dalam kategori masing-masing.
