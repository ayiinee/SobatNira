# Arsitektur dan integrasi

## Batas layanan

| Komponen | Tanggung jawab |
| --- | --- |
| Flutter | Aplikasi admin dan owner/manager, autentikasi pengguna, Pekerjaan, dashboard, traceability, konfigurasi, analitik dan ekspor sesuai izin |
| NestJS / TypeScript | API bisnis, otorisasi per tenant/pabrik, validasi, versi, audit, stok dan kalkulasi deterministik. Adapter WhatsApp menerima/mengirim pesan dan memeriksa status/identitas |
| FastAPI / Python | API internal untuk OCR/parser dan pemrosesan AI. Menghasilkan draf atau penjelasan untuk aplikasi melalui NestJS |
| Supabase Auth dan PostgreSQL | Identitas aplikasi serta penyimpanan relasional. NestJS memeriksa hak bisnis dan akses data |
| Redis/BullMQ | Rencana antrean untuk dokumen, percakapan, pengiriman pesan, ekspor. Redis juga dapat mendukung cache sesuai kebutuhan |
| Cloudflare R2 | Rencana penyimpanan bukti foto dan berkas ekspor privat |
| WhatsApp Business Cloud API, SMTP | Kanal operator, serta email untuk undangan, verifikasi dan pemulihan sesuai rancangan |
| OCR, parser, Gemini selektif dan OpenClaw | OCR awal, parsing per versi nota, pembacaan ulang bagian ambigu, konteks percakapan dan pemanggilan tool yang diizinkan |

NestJS mengirim permintaan pemrosesan internal ke FastAPI dan menerima hasil terstruktur. Penempatan worker, autentikasi antarlayanan, dan sinkron/asinkron ditetapkan bersama backend dan AI. Setup lokal membuktikan koneksi Flutter → NestJS → FastAPI dengan fixture tanpa kredensial. Implementasi antrean dan integrasi layanan eksternal masuk backlog sesuai kebutuhan demo.

## Referensi model data

- Tenant → pabrik → keanggotaan/role, operator, aset, konfigurasi dan versi formulir. Pemasok terkait tenant dengan konteks transaksi per pabrik.
- Kloter merujuk pemasok/pabrik. Batch merujuk wajan dan kloter konteks. Kontribusi nira merujuk batch dan kloter sumber dengan kuantitas. Transfer dan rework dicatat menurut material serta asal dan tujuan.
- Dokumen tahap memiliki revisi dan referensi foto. Baris dokumen dapat menunjuk batch bila tahap relevan. Hubungkan nilai ekstraksi, koreksi, pengesahan, dan pelaku.
- Batch memiliki hasil timbang dan grade. Simpan pergerakan stok, versi konfigurasi/harga, rekonsiliasi nilai, dan snapshot laporan agar hasil bisa diperiksa kembali.
- Simpan waktu kejadian, kirim, konfirmasi dan validasi. Rancangan awal mengusulkan menyimpan waktu dengan offset/UTC dan menampilkan waktu pabrik setempat. Tetapkan batas periode/shift bersama produk.

## Kontrak untuk dikerjakan tim

1. **WhatsApp → NestJS.** Event memuat ID pesan provider, identitas operator, waktu, dan referensi media. Tentukan autentikasi webhook, idempotensi, serta keadaan retry sebelum mengaktifkan adapter eksternal.
2. **NestJS → FastAPI.** Sepakati request/job ID, cakupan pabrik, tipe atau versi formulir, referensi foto privat, dan batas waktu. Respons berisi draf field/baris, satuan, tipe, penanda ambiguitas, serta kesalahan. Confidence dan koordinat berasal dari provider/model yang sudah diuji. Ekstraksi draf dapat diulang tanpa membentuk transaksi resmi ganda.
3. **Flutter → NestJS.** Sepakati DTO dan error untuk Pekerjaan, detail bukti, konfirmasi/pengesahan, koreksi, relasi kloter/batch, dashboard dan laporan. Gunakan status transaksi dan status pekerjaan secara eksplisit. Dokumen dari tenant/pabrik lain tidak bisa diakses melalui API maupun URL media.
4. **Analitik dan agent.** ProductionData, Traceability, Analytics dan ReportExport pada rancangan adalah kemampuan berbasis akses NestJS. Tool menggunakan identitas, periode dan cakupan pengguna. AI hanya merangkum angka resmi dan memberi referensi sumber.

## Operasional

Catat korelasi request, pesan, job, dokumen dan revisi. Hindari data pribadi, foto dan kredensial di log. Pekerjaan perlu bisa ditinjau/diteruskan ketika provider gagal. Retensi media, batas biaya dan SLA ditetapkan setelah uji. Target pilot awal dalam proposal adalah satu lokasi, sekitar 2–3 pengiriman foto bersamaan, estimasi 4 vCPU/8 GB RAM, dan unduhan aplikasi ≤100 MB. Ini asumsi perencanaan yang perlu diukur.
