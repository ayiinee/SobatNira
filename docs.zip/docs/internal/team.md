# Pembagian kerja

| Area | Pemilik | Tugas awal |
| --- | --- | --- |
| Flutter | Ferdi, Anjar | Ferdi dapat mulai dari Pekerjaan/detail nota, Anjar dari Beranda/daftar dan detail kloter. Sepakati pola state, penamaan rute dan batas peran sebelum menggabungkan |
| NestJS dan data | Aini, Alvin | Aini dapat mulai dari dokumen, status dan ACL, Alvin dari kloter/batch, kontribusi material dan fixture hitungan. Sepakati schema dan DTO bersama |
| WhatsApp dan OCR | Farel | Petakan jenis nota dan data minimum, sepakat kontrak FastAPI dengan backend, siapkan fixture lalu pilih jalur WhatsApp/OCR untuk demo |

Pembagian area dikonfirmasi. Pembagian tiket per orang dalam satu area adalah usulan. Ferdi/tim menyelaraskan prioritas demo. Pemilik konfirmasi SOP mitra perlu ditentukan.

## Urutan kerja dua minggu yang diusulkan

| Waktu relatif | Hasil |
| --- | --- |
| Hari 1–2 | Clone dan tes, cek akses Figma dan repo, tetapkan urutan demo, kontrak DTO, nota sintetis, dan pembagian tiket |
| Hari 3–6 | Sambungkan draf, konfirmasi dan antrean, detail Flutter dan validasi. Selesaikan jalur produksi normal |
| Hari 7–10 | Campuran, rework, traceability, stok dan koreksi. Sambungkan peran owner, analitik dan ekspor ke data yang sama |
| Hari 11–14 | Uji kasus gagal, stabilkan integrasi, kunci fixture/versi, jalankan gladi demo dan pilih fallback untuk fitur yang belum stabil |

## Kolaborasi

- Ambil satu tugas dari daftar di atas atau pecah dalam issue setelah tim menyepakati acceptance criteria. Cantumkan pemilik, data/kontrak yang dibutuhkan, dan contoh sukses/gagal.
- Ikuti [panduan kontribusi](../contributing.md) untuk struktur folder, penamaan branch dan commit, review kontrak, dan verifikasi PR.
- Gunakan fixture sintetis. Simpan rahasia di environment masing-masing. Nota, identitas operator, kredensial dan foto asli tidak masuk Git.
- Catat perubahan kebutuhan dan keputusan lintas komponen pada [register keputusan](decisions.md) agar tim memakai kontrak yang sama.
