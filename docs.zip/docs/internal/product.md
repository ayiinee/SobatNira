# Kebutuhan produk

## Masalah dan sasaran

Mitra awal adalah PT Tiga Dewi Timur Raya di Kediri. Proposal melaporkan sekitar 2–3 jam untuk rekap dan pemeriksaan silang nota serta buku produksi. SobatNira mempertahankan nota fisik dan kebiasaan operator memakai WhatsApp, lalu menghubungkan bukti, catatan produksi, stok, dan analitik untuk admin dan owner/manager.

Target pilot dari proposal adalah rekap ≤60 menit, kelengkapan data wajib setelah validasi ≥95%, dan penelusuran asal hasil ≤2 menit. Ketiganya masih target. Demo kompetisi memakai data sintetis dan urutan finalnya ditentukan tim. [Kriteria pengujian](demo-and-testing.md).

## Peran dan hak akses

| Kapabilitas | Operator | Admin | Owner/manager |
| --- | --- | --- | --- |
| Foto nota, klarifikasi, koreksi, konfirmasi | WhatsApp terdaftar | — | — |
| Notifikasi laporan baru | — | Ya | — |
| Periksa bukti, koreksi dan sahkan per dokumen | — | Ya | Ya |
| Dashboard, stok, penelusuran dan rekap operasional | — | Ya | Ya |
| Selesaikan/buka kembali kloter | — | Ya | Ya |
| Kelola operator dan konfigurasi produksi, termasuk harga | — | Ya | Ya |
| Kelola akun admin | — | — | Ya |
| Analitik produksi dan margin, penjelasan AI analitik, ekspor PDF/Excel | — | — | Ya |

Owner dan manager adalah satu role. Izin aplikasi berlaku untuk tenant dan pabrik yang diizinkan. Admin dapat mengubah harga operasional. Batas tampilan biaya dan akses AI operasional untuk admin masih perlu dirinci. Nomor operator dinonaktifkan segera kehilangan izin kirim laporan baru.

## Alur dan penerimaan

| Alur | Perilaku yang diharapkan |
| --- | --- |
| Pengiriman nota | Foto tersimpan sebagai bukti. Bot mengenali jenis nota atau meminta operator memilih tahap. Hasil yang terbaca menjadi draf. |
| Klarifikasi | Foto buram/terpotong meminta pengganti. Nilai ambigu dapat dikoreksi lewat percakapan. Bot menampilkan ulang ringkasan sebelum konfirmasi. |
| Konfirmasi WhatsApp | Konfirmasi langsung memindahkan laporan ke antrean admin. Gangguan diberitahukan jika kanal tersedia. Status sukses baru muncul ketika laporan siap ditinjau. |
| Validasi | Menu Pekerjaan memuat laporan Menunggu Validasi. Foto dan field dapat diperiksa berdampingan. Admin atau owner memeriksa kaitan dan mengesahkan per dokumen. |
| Perbaikan | Edit angka oleh petugas berwenang pada data sah menghasilkan revisi, audit dan kalkulasi ulang langsung. Revisi dari operator atas laporan sah diperiksa admin sebelum menggantikan versi efektif. |
| Duplikat dan pembaruan | Kiriman identik menghasilkan satu laporan. Foto nota dengan baris baru ditawarkan sebagai pembaruan, dikonfirmasi operator dan terhubung ke versi sebelumnya. |
| Kloter | Admin/owner dapat melihat status, membuka detail, menyelesaikan kloter, dan membuka kembali sebelum mengubah struktur material/batch yang sudah ditutup. |
| Dashboard | Tampilkan ringkasan produksi, status laporan, stok tebu/nira/gula per grade, produk gagal, dan tautan ke bukti/riwayat yang relevan. |
| Penelusuran | Dari pemasok atau kloter pengguna mencapai batch, hasil, grade, kontribusi nira, rework, dan dokumen sumber. Batch campuran menampilkan seluruh kloter asal. |
| Konfigurasi | Kelola wajan, kapasitas, grade, pegawai, bahan tambahan, harga dan parameter/formulir. Versi baru berlaku prospektif. |
| Analitik owner | Filter periode, pemasok, kloter, batch dan grade. Tampilkan produksi, rendemen, nilai, biaya, laba/margin, tren, dan sumber angka yang sudah disahkan. |
| AI dan ekspor owner | AI menjelaskan data sesuai izin dan cakupan. PDF/Excel berisi periode, waktu, kelengkapan, dan referensi sumber. Status selesai muncul setelah berkas tersedia bagi pengguna berizin. |

## Acuan desain

Alur layar dan istilah antarmuka mengacu ke [Figma SobatNira](https://www.figma.com/design/NY7ihgzpAKsRnRWub5tO6y/SobatNira?node-id=0-1). Kanvas memiliki varian Beranda, Kloter Semua, Tinjau, Tuntas dan filter tanggal. Definisikan keadaan memuat, kosong, gagal, konflik dan sukses untuk layar terkait. Label status perlu ditelusurkan ke keadaan backend sebelum implementasi UI.
