# Model bisnis dan skalabilitas

SobatNira diarahkan menjadi Vertical SaaS untuk pabrik gula merah tebu. Pihak pembeli yang dituju adalah owner/manajemen. Nilai yang diuji adalah penghematan rekap, kelengkapan, traceability, dan akses pengelola ke data produksi yang sudah diperiksa.

## Rancangan penawaran

- Dokumen Teknis Bab 6 mengusulkan langganan bulanan per lokasi pabrik/cabang, biaya implementasi sekali untuk konfigurasi dan pelatihan, serta tambahan kuota pemrosesan opsional.
- Reguler dan Intensif memiliki fitur inti serupa dengan kuota berbeda untuk formulir dan permintaan laporan berbantuan AI. Harga, kuota komersial dan willingness-to-pay harus diuji sebelum penawaran.
- Perkiraan biaya layanan harus merinci backend/database, antrean, penyimpanan, pesan, OCR, fallback Gemini, ekspor, dukungan dan onboarding. Hitung biaya variabel per dokumen/laporan dan alokasi biaya tetap per pabrik.
- Gunakan skenario rendah, sedang dan tinggi. Perkirakan beban foto utama sebagai `2 × kloter + 3 × batch` pada asumsi satu nota per tahap, lalu sesuaikan untuk nota multi-baris, revisi, kirim ulang dan pendukung. Ukur biaya serta perubahan pemakaian sebelum menghitung ulang margin layanan dan titik impas.
- Angka harga, margin dan titik impas pada Bab 6 merupakan simulasi. Operasional margin produksi mitra menggunakan aturan tersendiri di [proses produksi](production.md).

## Urutan pengembangan dan perluasan

1. Sepakati nota, grade, pencampuran, rework, dan contoh rekonsiliasi bersama mitra.
2. Bangun identitas tenant/pabrik, akses, audit, dan pencatatan hingga pengesahan.
3. Hubungkan kalkulasi, stok, konfigurasi versi, dashboard, penjelasan AI dan ekspor.
4. Uji kelayakan pilot pada satu lokasi. Ukur biaya dan kapasitas di jam sibuk. Bakukan pelatihan, backup/pemulihan dan dukungan.
5. Uji tenant sintetis kedua sebelum mencari perluasan ke pabrik sejenis. Skalakan kapasitas berdasarkan beban aktual, penggunaan kuota dan kebutuhan isolasi.
