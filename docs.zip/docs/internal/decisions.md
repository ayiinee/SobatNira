# Keputusan dan sumber

## Keputusan berdasarkan Q&A 14 November 2026

| Topik | Keputusan |
| --- | --- |
| Acuan | Dokumen Teknis Duluin Innovation sebagai acuan utama. Q&A terbaru memperjelas dan memperbarui detailnya |
| Target | Demo kompetisi sekitar dua minggu lagi, dengan alur wajib masih menunggu keputusan tim |
| Stack | NestJS API bisnis, Flutter aplikasi, FastAPI tetap dipakai sebagai API subsistem AI |
| Grade | Satu grade per batch. Gunakan berat dari penimbangan sebelum grading |
| Campuran | Alokasikan biaya dan laba sesuai proporsi liter nira ke kloter asal setelah validasi |
| Identitas | Kode kloter mengambil konteks supplier dan tanggal, dengan referensi contoh dari Figma |
| Pemilik area | Flutter Ferdi/Anjar, Backend Aini/Alvin, WhatsApp dan OCR Farel |
| Setup | Tim bisa clone, menjalankan Flutter dan backend secara lokal dengan fixture, menjalankan tes dan mengambil tugas awal |

## Pertanyaan terbuka

| Prioritas | Keputusan yang dibutuhkan | Pihak terkait |
| --- | --- | --- |
| Demo | Tanggal, durasi, urutan, dan cakupan live vs simulasi. Akses setiap anggota ke GitHub dan Figma | Tim |
| Nota | Sampel anonim lima tahap, kolom pencocokan, beberapa baris batch, kiriman di luar urutan dan perubahan versi | Farel, backend, mitra |
| Identitas | Format dan arti suffix kloter/batch, penanganan dua pengiriman serupa, pemilik keputusan ketika ambigu | Backend, Ferdi, mitra |
| Produksi | Daftar laporan wajib saat transfer, konsep jatah selain transfer nira, rework, waktu shift, satuan BTP/gamping | Backend dan mitra |
| Angka | Harga sumber, komponen biaya resmi, presisi/pembulatan alokasi, riwayat laporan setelah koreksi | Tim dan mitra |
| Hak akses | Visibilitas harga/biaya operasional admin, AI operasional, permintaan WA yang sedang berjalan saat operator dinonaktifkan | Backend, produk, mitra |
| Integrasi | Provider/benchmark OCR, biaya dan SLA, batas waktu, akses Meta, strategi job/retry, retensi dan izin penggunaan nota | Farel, backend |
| Pilot/SaaS | Syarat penggunaan mitra, waktu, onboarding, dukungan, harga/kuota dan perluasan | Tim dan mitra |

## Referensi

- **Ambarawa - Dokumen Teknis Duluin Innovation 2026.pdf**. Bab 1–2 masalah dan pasar, Bab 3 alur dan aturan, Bab 4 mockup, Bab 5 arsitektur dan ERD, Bab 6 unit ekonomi, Bab 7 demo pengembangan/pilot dan skalabilitas.
- **Ambarawa_Proposal DuluInnovation.pdf** dan **Proposal_Muhammad Farel Alfathir_Ambarawa.pdf**. Latar observasi, lampiran proses, formula, mockup dan jadwal historis.
- **SobatNira_Product_Understanding_v1.2_Knowledge_Lengkap.md** bagian A–R. Rekam audit, contoh, dan status keputusan sebelum Dokumen Teknis. **v1.1** serta **writing-block.md** adalah rekam versi awal.
- **Figma SobatNira**. Acuan tampilan, istilah dan contoh kode. [Desain](https://www.figma.com/design/NY7ihgzpAKsRnRWub5tO6y/SobatNira?node-id=0-1).
- **Q&A Ferdi, 14 November 2026**. Keputusan di tabel atas. Angka ilustrasi tetap diberi label sintetis. Materi sumber asli disimpan di luar repo.

### Rekonsiliasi sumber

- Stack lama menyebut FastAPI sebagai backend. Dokumen Teknis dan Q&A menetapkan NestJS untuk bisnis dan FastAPI untuk AI.
- `writing-block.md` menunggu produksi selesai sebelum meneruskan laporan. Dokumen Teknis dan v1.2 menetapkan penerusan per laporan sesudah konfirmasi operator.
- Dokumen lama memuat grade yang bisa terbaca sebagai beberapa kategori per batch. Dokumen Teknis dan Q&A menetapkan satu grade per batch.
- Kapasitas awal mengacu ke tiga wajan dan maksimum 115 L nira. Mockup lama pernah memuat pilihan wajan 1–4 dan bobot dalam kg.
- Proposal lama menetapkan target hackathon luas dan perkiraan pilot. Rencana kerja aktif berpusat pada demo kompetisi. Bab 6 memperbarui catatan lama yang belum memuat rancangan komersial.
