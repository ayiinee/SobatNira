# Demo, pengujian, dan pilot

Target kerja sekitar 28 November 2026. Tanggal resmi, durasi presentasi, dan daftar alur wajib menunggu tim. Cakupan kerja sementara menargetkan semua alur utama, dengan kedalaman live atau simulasi dipilih saat urutan demo disepakati.

## Urutan demo yang diusulkan

1. Operator terdaftar mengirim foto nota sintetis melalui WhatsApp atau simulator yang diberi label. Peragakan draf, koreksi, konfirmasi dan satu contoh foto yang harus dikirim ulang.
2. Admin menerima antrean, membandingkan foto dan hasil, mengoreksi atau mengaitkan laporan, lalu mengesahkan. Tunjukkan jejak satu pembaruan atau duplikat.
3. Hubungkan penerimaan, penggilingan, pemasakan, penimbangan dan grading. Sertakan batch biasa, campuran 20/80 L, satu rework, dan penyelesaian kloter setelah transfer.
4. Tampilkan dashboard, stok, konfigurasi yang berlaku untuk produksi berikutnya, dan penelusuran hasil kembali ke sumber.
5. Ganti ke owner/manager. Peragakan filter analitik, porsi biaya/laba tiap kloter, jawaban AI berbasis sumber dan ekspor. Pastikan batas admin bisa dibuktikan.

## Kriteria uji

| Area | Kasus yang wajib diperiksa sebelum diklaim berjalan |
| --- | --- |
| Setup | Instal dari salinan baru, jalankan tiga komponen dan tes, buka Flutter, lihat fixture dari API |
| Alur dokumen | Foto memicu draf/keadaan gagal, konfirmasi langsung masuk antrean, validasi per dokumen, revisi operator perlu ditinjau, pengiriman ulang identik idempoten |
| Hak akses | Operator aktif/nonaktif, admin tanpa analitik/ekspor, owner berizin, penolakan akses lintas tenant/pabrik dan bukti |
| Identitas | Dua kiriman supplier di hari sama, dua run di wajan yang sama, laporan datang tidak berurutan, ambiguitas dapat ditangani |
| Material | Satu grade per batch, satuan L/kg, transfer, campuran 20/80 dan rework dapat ditelusuri serta stok terjaga |
| Ekonomi | Biaya/laba campuran direkonsiliasi ke kloter, hasil tetap konsisten setelah koreksi, snapshot ekspor bisa dilacak |
| Gangguan | Provider timeout, media tidak terbaca, retry, worker restart dan kiriman ganda dengan jejak status yang jelas |
| Antarmuka | Loading, kosong, error, sukses, perpindahan peran dan akses bukti. Cek Chrome untuk setup dan perangkat Android untuk demo mobile |

## Evaluasi pilot setelah demo

- Ukur kelengkapan wajib setelah validasi ≥95%, waktu rekap ≤60 menit, dan traceability ≤2 menit. Bandingkan dengan kondisi awal pada skenario dan ukuran sampel yang dicatat.
- Siapkan transkripsi rujukan untuk kelima jenis nota dengan variasi tulisan, baris, satuan, coretan, pencahayaan, gambar buram dan kiriman ulang. Ukur ketepatan angka/field dan pasangan baris, koreksi manusia, retry, latensi ke draf, dan biaya per dokumen.
- Tentukan ambang OCR, biaya, beban, retensi, penanganan insiden dan pemulihan berdasarkan hasil uji. Gunakan data mitra setelah izin dan tata kelola disepakati.
- Sebelum pilot, verifikasi izin dan isolasi, rekonsiliasi stok dan alokasi, audit koreksi, stabilitas ekspor, serta pelatihan dan dukungan lintas shift. Waktu pilot aktual menunggu kesepakatan mitra.
